#!/usr/bin/env python

from distutils.core import setup

setup(name='qubench',
      version='0.1',
      description='Sql query benchmark',
      author='Alexander Gulyaev',
      author_email='alexander-vgx@yandex.ru',
     )